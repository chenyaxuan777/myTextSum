import json

# 判断sections_list中是否包含以sections_str前缀为开头的section_name
def helper(sections_list, sections_str):
    for sections in sections_list:
        pass


def delArticleText(source, targetTrue, targetFalse):
    with open(source, 'r') as inputs:
        with open(targetTrue, 'a+') as outputT, open(targetFalse, 'a+') as outputF:
            for line in inputs:
                line_dict = json.loads(line)
                line_list = line_dict["section_names"]

                del line_dict["article_text"]
                line_str = json.dumps(line_dict)
                outputT.writelines(line_str+'\n')

