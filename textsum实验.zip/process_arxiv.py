import json
from collections import Counter
filename = "E:\\paper\\数据集\\arxiv摘要\\arxiv-dataset\\val.txt"
filename2 = "E:\paper\\数据集\\arxiv摘要\\arxiv-dataset\\mytest.txt"
filename3 = "E:\\paper\\数据集\\arxiv摘要\\arxiv-dataset\\vall.json"
chen = "E:\\paper\\数据集\\arxiv摘要\\arxiv-dataset\\chen.txt"
# 读取前N行数据
N = 1
# 所有文章的所有section_name合集
section_name_info = []
# 文章数目
paper_nums = 0

with open(filename) as file:
    files = file.readlines()
    paper_nums = len(files)
    cur_nums = 0
    for line in files:
        line_dict = json.loads(line)
        section_name = line_dict["section_names"]
        section_name_info.extend(section_name)
        cur_nums += 1

        if cur_nums % 500 == 0 or cur_nums == paper_nums :
            print("当前信息：第%d句" %(cur_nums))
            print("section_name", section_name)
            print("section_name_info:", section_name_info)
            print("---------------------------------------------------------------------------------------------------")

c = Counter(section_name_info)
print(c)

# 每一篇文章只要 article_id, abstract_text, section_names, sections
# 统计每篇文章