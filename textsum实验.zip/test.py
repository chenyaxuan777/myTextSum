from collections import Counter
import json

path = "E:\\paper\\数据集\\arxiv摘要\\arxiv-dataset\\processed_data\\section_names_val.txt"

countsHead = []
countsTail1 = []
countsTail2 = []
countsLen = 0
sumLen = 0

intro_sum = 0
summar_conclu_sum = 0
total_sum = 0
one_sum = 0
i = 0
output = ""
with open(path, 'r') as file:
    # lines = file.readlines()
    #  sumLen = len(lines)
    # opt = open(output, 'a+')
    for line in file:
        i += 1
        # if i > 10000:
        #     break
        line_dict = json.loads(line)
        line_list = line_dict['section_names']
        flag1, flag2 = False, False
        for line_list_str in line_list:
            if "introd" in line_list_str:
                flag1 = True
            if ("conclu" in line_list_str) or ("summar" in line_list_str) or ("discuss" in line_list_str) or ("resul" in line_list_str):
                flag2 = True
        if flag1:
            intro_sum += 1          # 有介绍部分的数目
        if flag2:
            summar_conclu_sum += 1  # 有结语部分的数目
        if flag1 and flag2:
            total_sum += 1          # 介绍部分和结语部分都有的数目
        if flag1 == False and flag2 == False:
            line_str = json.dumps(line_dict)


        countsHead.append(line_list[0])     # 所有第一章节的名字
        if "introd" in line_list[0]:
            one_sum += 1                    # 第一章就是introduction的数量
        countsTail1.append(line_list[-1])   # 所有最后一章节的名字
        if len(line_list) > 2:
            countsTail2.append(line_list[-2])   # 倒数第二章节的名字
            countsLen += 1

ch = Counter(countsHead)
ct1 = Counter(countsTail1)
ct2 = Counter(countsTail2)
print("统计第一章情况：", ch)
print("统计最后一章情况：", ct1)
print("统计倒数第二章情况：", ct2)
print("有介绍部分的数目: ", intro_sum)
print("有结语部分的数目: ", summar_conclu_sum)
print("介绍部分和结语部分都有的数目: ", total_sum)
print("第一章就是introduction的数量: ", one_sum)
# print(sumLen)